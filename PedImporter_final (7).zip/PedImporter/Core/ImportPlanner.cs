using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace PedImporter.Core
{
    /// <summary>
    /// یه ردیف پیش‌نمایش: یه drawable مبدأ که قراره با اسم/ایندکس جدید به مقصد اضافه بشه.
    /// </summary>
    public class ImportItem
    {
        public ClothingDrawable Source { get; set; }

        /// <summary>ایندکس پیش‌بینی‌شده برای نمایش تو پیش‌نمایش/ویرایش دستی کاربر.</summary>
        public int NewIndex { get; set; }

        public bool HasMismatch => Source.YddPath == null || Source.Textures.Count == 0;

        /// <summary>
        /// true یعنی این آیتم اولین چیزیه که رو یه کامپوننت کاملاً تازه (که این پد قبلاً
        /// اصلاً نداشتش) اضافه می‌شه.
        ///
        /// نکته‌ی مهم درباره‌ی «ایندکس ۰ محفوظ بمونه»: با تست واقعی (نه فقط تئوری) روی خودِ
        /// ig_De3.ymt ثابت شد که وقتی یه کامپوننت کاملاً تازه‌ست، اولین آیتم واقعی که براش
        /// اضافه می‌شه به‌طور طبیعی دقیقاً رو ایندکس ۰ می‌شینه — چون ایندکس همیشه از رو تعداد
        /// واقعیِ drawable های موجود تو خودِ سند ymt حساب می‌شه (نگاه کن به
        /// YmtComponentEditor.AddComponentDrawable)، و برای یه کامپوننت تازه این تعداد صفره.
        /// یعنی همون چیزی که خودت خواستی (۰۰۰ همیشه یه چیز واقعی و سالم نشون بده، نه چیز
        /// شکسته/گم‌شده) بدون هیچ کار اضافه‌ای، بدون ساختن نسخه‌ی تکراری، و بدون هیچ entry
        /// جعلی به‌طور خودکار برقراره — دقیقاً مثل feet_000/hand_000/head_000 که تو همین پد
        /// از قبل محتوای واقعی‌ان. پس دیگه نیازی به یه مکانیزم جدا برای «دوبار کپی کردن رو
        /// ۰۰۰ و ۰۰۱» نیست؛ این فیلد فقط برای اطلاع تو پیش‌نمایشه.
        /// </summary>
        public bool IsFirstItemOfNewComponent { get; set; }

        public List<(string OldPath, string NewName)> GetFileRenames(string destPedName, int targetIndex)
        {
            bool isProp = FileNameParser.PropAnchorIds.ContainsKey(Source.Component);
            const string alphas = "abcdefghijklmnopqrstuvwxyz";
            var list = new List<(string, string)>();
            if (Source.YddPath != null)
            {
                var newYddName = isProp
                    ? FileNameParser.BuildPropYddFileName(destPedName, Source.Component, targetIndex)
                    : FileNameParser.BuildYddFileName(destPedName, Source.Component, targetIndex, Source.YddSuffix);
                list.Add((Source.YddPath, newYddName));
            }
            // حرف تکسچر (a, b, c...) از موقعیت تو لیست ساخته می‌شه، نه از اسم فایل مبدأ —
            // چون بازی از رو موقعیت تو aTexData حرفش رو حساب می‌کنه.
            for (int i = 0; i < Source.Textures.Count; i++)
            {
                var tex = Source.Textures[i];
                string letter = alphas[i % alphas.Length].ToString();
                var newYtdName = isProp
                    ? FileNameParser.BuildPropDiffYtdFileName(destPedName, Source.Component, targetIndex, letter)
                    : FileNameParser.BuildDiffYtdFileName(destPedName, Source.Component, targetIndex, letter, tex.TexSuffix);
                list.Add((tex.Path, newYtdName));
            }
            return list;
        }
    }

    public static class ImportPlanner
    {
        /// <summary>
        /// برای هر drawable انتخاب‌شده از مبدأ، ایندکس بعدی رو *پیش‌بینی* می‌کنه تا تو
        /// پیش‌نمایش نشون داده بشه و کاربر بتونه دستی عوضش کنه. این فقط یه پیش‌بینیه —
        /// ایندکس واقعی و نهایی همیشه تو ExecuteImport مستقیماً از رو خودِ سند ymt (نه از
        /// رو اسم فایل‌ها) گرفته می‌شه، تا هیچ‌وقت اسم فایل با محتوای واقعی ymt ناجور نشه.
        ///
        /// fillGaps=false (پیش‌فرض): همیشه از رو بزرگ‌ترین ایندکس موجود، +۱.
        /// fillGaps=true: کوچیک‌ترین ایندکس آزاد (بر اساس اسکن فایل‌های مقصد) رو پیشنهاد می‌ده.
        ///   توجه: چون خودِ ymt یه آرایه‌ی متراکمه (نمی‌شه وسطش یه جای خالی گذاشت بدون
        ///   جابه‌جا کردن همه‌ی آیتم‌های بعدیش)، این گزینه فقط زمانی واقعاً یه ایندکس آزاد
        ///   پیدا می‌کنه که خودِ فایل‌های مقصد یه شکاف واقعی داشته باشن؛ ExecuteImport قبل
        ///   از اجرا این پیش‌بینی رو با تعداد واقعی درون ymt چک می‌کنه و اگه ناهم‌خوان بود
        ///   هشدار می‌ده (نه اینکه کورکورانه فایل رو با اسم اشتباه بسازه).
        /// </summary>
        public static List<ImportItem> PlanImport(List<ClothingDrawable> selectedSourceItems, List<ClothingDrawable> destDrawables, bool fillGaps = false)
        {
            var usedByComponent = new Dictionary<string, SortedSet<int>>(StringComparer.OrdinalIgnoreCase);
            foreach (var d in destDrawables)
            {
                if (!usedByComponent.TryGetValue(d.Component, out var set))
                {
                    set = new SortedSet<int>();
                    usedByComponent[d.Component] = set;
                }
                set.Add(d.Index);
            }

            var plan = new List<ImportItem>();
            foreach (var src in selectedSourceItems)
            {
                bool isBrandNewComponent = !usedByComponent.ContainsKey(src.Component);
                if (!usedByComponent.TryGetValue(src.Component, out var used))
                {
                    used = new SortedSet<int>();
                    usedByComponent[src.Component] = used;
                }

                bool isProp = FileNameParser.PropAnchorIds.ContainsKey(src.Component);
                int predicted;
                bool skipZero = !isProp && YmtComponentEditor.ReservedZeroComponents.Contains(src.Component);
                if (fillGaps)
                {
                    predicted = skipZero ? 1 : 0;
                    while (used.Contains(predicted)) predicted++;
                }
                else
                {
                    predicted = used.Count == 0 ? (skipZero ? 1 : 0) : used.Max + 1;
                }

                if (isBrandNewComponent && skipZero) used.Add(0); // ۰ فقط برای اختیاری‌ها با placeholder اشغاله

                used.Add(predicted);

                plan.Add(new ImportItem
                {
                    Source = src,
                    NewIndex = predicted,
                    IsFirstItemOfNewComponent = isBrandNewComponent
                });
            }
            return plan;
        }

        /// <summary>
        /// چک می‌کنه آیتم‌های پلن قبلاً import نشده باشن (با خوندن import_manifest.log کنار
        /// ymt). این دقیقاً همون مشکلیه که باعث می‌شه اگه یه بار دیگه با همون انتخاب اجرا
        /// کنی، همون لباس‌ها دوباره با ایندکس بالاتر اضافه بشن و پوشه با ymt جفت نشه.
        /// </summary>
        public static List<string> ValidatePlan(List<ImportItem> plan, XmlDocument destYmtDoc, string ymtPathForManifestCheck = null)
        {
            var errors = new List<string>();
            var alreadyImported = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (!string.IsNullOrEmpty(ymtPathForManifestCheck))
            {
                var manifestPath = Path.Combine(Path.GetDirectoryName(ymtPathForManifestCheck), "import_manifest.log");
                if (File.Exists(manifestPath))
                {
                    foreach (var line in File.ReadAllLines(manifestPath))
                    {
                        // خطوط موفق شکلشون اینه: "oran^feet_003 -> De3^feet_003  (10 texture)..."
                        var arrow = line.IndexOf(" -> ");
                        if (arrow > 0 && !line.TrimStart().StartsWith("⚠") && !line.TrimStart().StartsWith("---"))
                        {
                            alreadyImported.Add(line.Substring(0, arrow).Trim());
                        }
                    }
                }
            }

            foreach (var item in plan)
            {
                if (item.HasMismatch)
                {
                    errors.Add($"{item.Source.Key}: ydd یا texture نداره.");
                }
                foreach (var tex in item.Source.Textures)
                {
                    if (!YmtComponentEditor.TexSuffixToId.ContainsKey(tex.TexSuffix))
                    {
                        errors.Add($"{item.Source.Key}: پسوند تکسچر ناشناخته '{tex.TexSuffix}' (فایل {Path.GetFileName(tex.Path)}).");
                    }
                }
                if (alreadyImported.Contains(item.Source.Key))
                {
                    errors.Add($"{item.Source.Key}: قبلاً import شده (تو import_manifest.log کنار ymt ثبته) — اجرا متوقف می‌شه که دوباره اضافه نشه. اگه واقعاً می‌خوای دوباره اضافه‌ش کنی، خط مربوطش رو از import_manifest.log پاک کن و دوباره امتحان کن.");
                }
            }
            return errors;
        }

        /// <summary>
        /// اجرای واقعی. نکته‌ی حیاتی: برای هر آیتم، اول AddComponentDrawable رو صدا می‌زنیم
        /// و ایندکس *واقعی*ای که خودِ سند ymt برمی‌گردونه رو می‌گیریم، و فقط بعدش، بر اساس
        /// همون ایندکس واقعی (نه پیش‌بینیِ PlanImport)، اسم فایل‌ها رو می‌سازیم و کپی می‌کنیم.
        /// این یعنی اسم فایل روی دیسک تضمینی همیشه دقیقاً با چیزی که تو ymt ثبت شده یکیه —
        /// حتی اگه fillGaps یا ویرایش دستیِ کاربر تو پیش‌نمایش با واقعیت ymt جور درنیاد،
        /// همون‌جا لاگ هشدار می‌گیری، نه یه فایل با اسم اشتباه.
        ///
        /// برای کامپوننت‌های کاملاً تازه، بدون هیچ کار اضافه‌ای، اولین آیتم واقعی خودش دقیقاً
        /// رو ایندکس ۰ می‌شینه (چون AddComponentDrawable ایندکس رو از رو تعداد واقعیِ
        /// drawable های موجود می‌سازه، و برای کامپوننت تازه این عدد صفره) — یعنی ۰۰۰ همیشه
        /// یه محتوای واقعی و کامل داره، دقیقاً مثل feet_000/hand_000/head_000 که از قبل تو
        /// همین پد هستن. این با تست واقعی روی خودِ ig_De3.ymt تأیید شده.
        /// </summary>
        public static List<string> ExecuteImport(List<ImportItem> plan, string destStreamFolder, string destPedName, XmlDocument destYmtDoc, string ymtPath = null)
        {
            var errors = ValidatePlan(plan, destYmtDoc, ymtPath);
            var log = new List<string>();
            if (errors.Count > 0)
            {
                log.Add("این آیتم‌ها مشکل داشتن و رد شدن (بقیه اجرا می‌شن):");
                foreach (var e in errors) log.Add("  ⚠ " + e);
                var badKeys = new HashSet<string>(errors.Select(e => e.Split(':')[0].Trim()), StringComparer.OrdinalIgnoreCase);
                plan = plan.Where(it => !badKeys.Contains(it.Source.Key)).ToList();
            }

            foreach (var item in plan)
            {
                bool isProp = FileNameParser.PropAnchorIds.ContainsKey(item.Source.Component);
                var texSuffixes = item.Source.Textures.Select(t => t.TexSuffix).ToList();
                int realIndex;
                string note;

                if (isProp)
                {
                    realIndex = YmtComponentEditor.AddPropDrawable(destYmtDoc, item.Source.Component, texSuffixes);
                    note = item.IsFirstItemOfNewComponent ? "  [اولین پراپ این slot]" : "";
                }
                else
                {
                    YmtComponentEditor.EnsureComponentSlot(destYmtDoc, item.Source.Component);
                    realIndex = YmtComponentEditor.AddComponentDrawable(destYmtDoc, item.Source.Component, texSuffixes, item.Source.YddSuffix);
                    note = (item.IsFirstItemOfNewComponent && realIndex == 0)
                        ? "  [کامپوننت تازه — این آیتم خودش دقیقاً رو ۰۰۰ نشست، محتوای واقعیه]"
                        : (item.IsFirstItemOfNewComponent && YmtComponentEditor.ReservedZeroComponents.Contains(item.Source.Component))
                        ? "  [کامپوننت اختیاریِ تازه — ۰۰۰ خودکار بدون فایل/خالی موند («هیچی»)، این آیتم رفت رو ۰۰۱]"
                        : "";
                }

                if (!isProp && realIndex != item.NewIndex)
                {
                    log.Add($"⚠ {item.Source.Key}: پیش‌نمایش ایندکس {item.NewIndex} رو نشون می‌داد ولی ایندکس واقعیِ ymt {realIndex} شد — از همین {realIndex} استفاده شد (منبع درست همیشه خودِ ymt هست).");
                }

                foreach (var (oldPath, newName) in item.GetFileRenames(destPedName, realIndex))
                {
                    File.Copy(oldPath, Path.Combine(destStreamFolder, newName), overwrite: false);
                }
                log.Add($"{item.Source.Key} -> {destPedName}^{item.Source.Component}_{realIndex:D3}  ({texSuffixes.Count} texture){note}");
            }

            return log;
        }

        public static string BackupYmt(string ymtPath)
        {
            var dir = Path.GetDirectoryName(ymtPath);
            var backupDir = Path.Combine(dir, "backup");
            Directory.CreateDirectory(backupDir);
            var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            var backupPath = Path.Combine(backupDir, Path.GetFileNameWithoutExtension(ymtPath) + "_" + stamp + ".ymt");
            File.Copy(ymtPath, backupPath, overwrite: false);
            return backupPath;
        }

        /// <summary>
        /// یه لاگ ساده (append-only) کنار خودِ ymt می‌نویسه، تا بعداً بتونی ببینی کِی چی از
        /// کجا اضافه شده. مشکلی تو ساخت لاگ باعث نمی‌شه import شکست بخوره.
        /// </summary>
        public static void AppendManifest(string ymtPath, List<string> executionLog)
        {
            try
            {
                var dir = Path.GetDirectoryName(ymtPath);
                var manifestPath = Path.Combine(dir, "import_manifest.log");
                var sb = new StringBuilder();
                sb.AppendLine($"--- {DateTime.Now:yyyy-MM-dd HH:mm:ss} ---");
                foreach (var line in executionLog) sb.AppendLine(line);
                File.AppendAllText(manifestPath, sb.ToString(), Encoding.UTF8);
            }
            catch
            {
                // لاگ صرفاً اطلاع‌رسانیه؛ اگه نوشتنش خطا داد نباید کل import رو خراب کنه.
            }
        }
    }
}
