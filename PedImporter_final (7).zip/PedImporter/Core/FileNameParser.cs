using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace PedImporter.Core
{
    /// <summary>
    /// یه drawable واحد از یه ped (یعنی یه فایل ydd + همه‌ی diff/ytd هایی که باهاش میان).
    /// </summary>
    public class ClothingDrawable
    {
        public string PedName { get; set; }
        public string Component { get; set; }   // lowercase, e.g. "feet", "jbib" — همون‌طور که تو اسم فایل اومده
        public int Index { get; set; }           // ایندکس 3 رقمی که تو اسم فایل بود (مثلاً 007)
        public string YddSuffix { get; set; }    // حرف بعد از ایندکس تو خود ydd، معمولاً "u"
        public string YddPath { get; set; }
        public List<DiffTexture> Textures { get; } = new List<DiffTexture>();

        public string Key => $"{PedName}^{Component}_{Index:D3}";

        public override string ToString()
        {
            return $"{Key} ({Textures.Count} texture{(Textures.Count == 1 ? "" : "s")})";
        }
    }

    public class DiffTexture
    {
        public string Variant { get; set; }   // حرف variant: a, b, c, ...
        public string TexSuffix { get; set; } // uni یا whi (یا هر چی بعدش باشه)
        public string Path { get; set; }
    }

    /// <summary>
    /// اسکن یه پوشه (مثلاً stream یه ped) و گروه‌بندی فایل‌های ydd/ytd بر اساس
    /// ped name + component + index — دقیقاً طبق پترنی که تو چت توضیح داده شد:
    ///   ig_&lt;Ped&gt;^&lt;Component&gt;_&lt;Index3&gt;_&lt;Suffix&gt;.ydd
    ///   ig_&lt;Ped&gt;^&lt;Component&gt;_diff_&lt;Index3&gt;_&lt;Variant&gt;_&lt;uni|whi&gt;.ytd
    /// </summary>
    public static class FileNameParser
    {
        // ig_De3^feet_007_u.ydd
        private static readonly Regex YddPattern = new Regex(
            @"^(?<ped>[^^]+)\^(?<comp>[a-zA-Z]+)_(?<idx>\d{3})_(?<suffix>[a-zA-Z]+)\.ydd$",
            RegexOptions.IgnoreCase);

        // ig_De3^feet_diff_007_a_uni.ytd
        private static readonly Regex DiffYtdPattern = new Regex(
            @"^(?<ped>[^^]+)\^(?<comp>[a-zA-Z]+)_diff_(?<idx>\d{3})_(?<variant>[a-zA-Z])_(?<texsuffix>[a-zA-Z]+)\.ytd$",
            RegexOptions.IgnoreCase);

        // ig_deanquincy_p^p_eyes_000.ydd  (نه p_ اول، بلکه ig_ + پسوند _p رو اسم پد)
        private static readonly Regex PropYddPattern = new Regex(
            @"^(?<ped>[^^]+)\^p_(?<slot>[a-zA-Z]+)_(?<idx>\d{3})\.ydd$",
            RegexOptions.IgnoreCase);
        private static readonly Regex PropDiffYtdPattern = new Regex(
            @"^(?<ped>[^^]+)\^p_(?<slot>[a-zA-Z]+)_diff_(?<idx>\d{3})_(?<variant>[a-zA-Z])\.ytd$",
            RegexOptions.IgnoreCase);

        public static readonly Dictionary<string, byte> PropAnchorIds = new Dictionary<string, byte>(StringComparer.OrdinalIgnoreCase)
        {
            { "head", 0 }, { "eyes", 1 }, { "ears", 2 }, { "lwrist", 6 }, { "rwrist", 7 }
        };
        public static readonly Dictionary<byte, string> PropAnchorNames = new Dictionary<byte, string>
        {
            { 0, "ANCHOR_HEAD" }, { 1, "ANCHOR_EYES" }, { 2, "ANCHOR_EARS" }, { 6, "ANCHOR_LEFT_WRIST" }, { 7, "ANCHOR_RIGHT_WRIST" }
        };

        public static List<ClothingDrawable> ScanPropsFolder(string folderPath)
        {
            var files = Directory.GetFiles(folderPath);
            var props = new Dictionary<string, ClothingDrawable>(StringComparer.OrdinalIgnoreCase);
            foreach (var file in files)
            {
                var name = Path.GetFileName(file);
                var m = PropYddPattern.Match(name);
                if (!m.Success) continue;
                var d = new ClothingDrawable
                {
                    PedName = m.Groups["ped"].Value,
                    Component = m.Groups["slot"].Value.ToLowerInvariant(),
                    Index = int.Parse(m.Groups["idx"].Value),
                    YddSuffix = "u", // پراپ‌ها تو اسم فایل پسوند u/r ندارن، همیشه یکسانه
                    YddPath = file
                };
                props[d.Key] = d;
            }
            foreach (var file in files)
            {
                var name = Path.GetFileName(file);
                var m = PropDiffYtdPattern.Match(name);
                if (!m.Success) continue;
                string ped = m.Groups["ped"].Value;
                string slot = m.Groups["slot"].Value.ToLowerInvariant();
                int idx = int.Parse(m.Groups["idx"].Value);
                string key = $"{ped}^{slot}_{idx:D3}";
                if (!props.TryGetValue(key, out var d))
                {
                    d = new ClothingDrawable { PedName = ped, Component = slot, Index = idx, YddSuffix = "u" };
                    props[key] = d;
                }
                // پراپ‌ها تو اسم دیف‌شون texId ندارن (uni/whi/...) — همیشه texId=0 می‌ذاریم
                d.Textures.Add(new DiffTexture { Variant = m.Groups["variant"].Value, TexSuffix = "uni", Path = file });
            }
            return props.Values.OrderBy(d => d.Component).ThenBy(d => d.Index).ToList();
        }

        /// <summary>
        /// اسم Ped ورودی رو تمیز می‌کنه — اگه کاربر خودش "ig_" جلوش نوشته باشه (چون تو
        /// اسم فایل‌ها همیشه همونو می‌بینه) حذفش می‌کنه، تا پیشوند دوباره اضافه نشه و
        /// "ig_ig_..." ساخته نشه.
        /// </summary>
        static string NormalizePedName(string pedName)
        {
            pedName = (pedName ?? "").Trim();
            if (pedName.StartsWith("ig_", StringComparison.OrdinalIgnoreCase))
                pedName = pedName.Substring(3);
            return pedName;
        }

        public static string BuildPropYddFileName(string newPedName, string slot, int newIndex)
            => $"ig_{NormalizePedName(newPedName)}_p^p_{slot}_{newIndex:D3}.ydd";
        public static string BuildPropDiffYtdFileName(string newPedName, string slot, int newIndex, string variant)
            => $"ig_{NormalizePedName(newPedName)}_p^p_{slot}_diff_{newIndex:D3}_{variant}.ytd";

        public static List<ClothingDrawable> ScanFolder(string folderPath)
        {
            var files = Directory.GetFiles(folderPath);
            var drawables = new Dictionary<string, ClothingDrawable>(StringComparer.OrdinalIgnoreCase);

            // اول همه‌ی ydd ها رو پیدا کن، هر کدوم یه drawable جدید می‌سازه
            foreach (var file in files)
            {
                var name = Path.GetFileName(file);
                var m = YddPattern.Match(name);
                if (!m.Success) continue;

                var d = new ClothingDrawable
                {
                    PedName = m.Groups["ped"].Value,
                    Component = m.Groups["comp"].Value.ToLowerInvariant(),
                    Index = int.Parse(m.Groups["idx"].Value),
                    YddSuffix = m.Groups["suffix"].Value,
                    YddPath = file
                };
                drawables[d.Key] = d;
            }

            // بعد diff ytd ها رو به drawable متناظرشون وصل کن
            foreach (var file in files)
            {
                var name = Path.GetFileName(file);
                var m = DiffYtdPattern.Match(name);
                if (!m.Success) continue;

                var ped = m.Groups["ped"].Value;
                var comp = m.Groups["comp"].Value.ToLowerInvariant();
                var idx = int.Parse(m.Groups["idx"].Value);
                var key = $"{ped}^{comp}_{idx:D3}";

                if (!drawables.TryGetValue(key, out var d))
                {
                    // ytd بدون ydd متناظر — ثبتش می‌کنیم جدا تا هشدار داده بشه، نه این‌که گم بشه
                    d = new ClothingDrawable
                    {
                        PedName = ped,
                        Component = comp,
                        Index = idx,
                        YddPath = null
                    };
                    drawables[key] = d;
                }

                d.Textures.Add(new DiffTexture
                {
                    Variant = m.Groups["variant"].Value.ToLowerInvariant(),
                    TexSuffix = m.Groups["texsuffix"].Value.ToLowerInvariant(),
                    Path = file
                });
            }

            var result = drawables.Values.ToList();
            foreach (var d in result)
            {
                d.Textures.Sort((a, b) => string.Compare(a.Variant, b.Variant, StringComparison.OrdinalIgnoreCase));
            }
            result.Sort((a, b) =>
            {
                int c = string.Compare(a.Component, b.Component, StringComparison.OrdinalIgnoreCase);
                return c != 0 ? c : a.Index.CompareTo(b.Index);
            });
            return result;
        }

        /// <summary>
        /// برای هر کامپوننت تو پوشه‌ی مقصد، بزرگ‌ترین ایندکس موجود رو پیدا می‌کنه.
        /// خروجی: dictionary از component (lowercase) به بزرگ‌ترین ایندکس (یا -1 اگه اصلاً نبود).
        /// </summary>
        public static Dictionary<string, int> GetMaxIndexPerComponent(List<ClothingDrawable> destDrawables)
        {
            var result = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var d in destDrawables)
            {
                if (!result.TryGetValue(d.Component, out var cur) || d.Index > cur)
                {
                    result[d.Component] = d.Index;
                }
            }
            return result;
        }

        /// <summary>
        /// اسم فایل جدید (ydd یا ytd) رو با ped name و index جدید می‌سازه، بقیه‌ی
        /// قسمت‌های اسم (suffix, variant, texsuffix) رو دست‌نخورده نگه می‌داره.
        /// </summary>
        public static string BuildYddFileName(string newPedName, string component, int newIndex, string suffix)
        {
            return $"ig_{NormalizePedName(newPedName)}^{component}_{newIndex:D3}_{suffix}.ydd";
        }

        public static string BuildDiffYtdFileName(string newPedName, string component, int newIndex, string variant, string texSuffix)
        {
            return $"ig_{NormalizePedName(newPedName)}^{component}_diff_{newIndex:D3}_{variant}_{texSuffix}.ytd";
        }
    }
}
