using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using CodeWalker.GameFiles;

namespace PedImporter.Core
{
    /// <summary>
    /// خوندن/نوشتن ymt به‌عنوان XmlDocument، با استفاده از CodeWalker.Core.
    /// </summary>
    public static class YmtIo
    {
        public static XmlDocument LoadYmtAsXml(string ymtPath)
        {
            byte[] data = File.ReadAllBytes(ymtPath);

            YmtFile ymt = new YmtFile();
            ymt.Load(data);

            if (ymt.RpfFileEntry == null)
            {
                ymt.RpfFileEntry = new RpfResourceFileEntry
                {
                    Name = Path.GetFileName(ymtPath)
                };
            }

            string xml = MetaXml.GetXml(ymt, out _);
            if (string.IsNullOrEmpty(xml))
            {
                throw new Exception($"نتونستم {ymtPath} رو به XML تبدیل کنم — فرمتش پشتیبانی نمی‌شه یا خرابه.");
            }

            var doc = new XmlDocument();
            doc.LoadXml(xml);
            return doc;
        }

        public static void SaveXmlAsYmt(XmlDocument doc, string outputYmtPath)
        {
            byte[] data = XmlMeta.GetRSCData(doc);
            if (data == null)
            {
                throw new Exception("XmlMeta.GetRSCData چیزی برنگردوند — ساختار XML با Meta جور درنمیاد.");
            }
            File.WriteAllBytes(outputYmtPath, data);
        }
    }

    /// <summary>
    /// اضافه کردن یه drawable جدید به CPedVariationInfo.
    ///
    /// نکته‌ی مهم (اصلاح‌شده): برخلاف نسخه‌ی قبلی، اینجا دیگه فرض نمی‌کنیم که ایندکس ۰۰۰
    /// یه کامپوننت باید همیشه خالی/placeholder بمونه. تو خودِ ymt این پد (ig_De3)، فایل‌های
    /// واقعی feet_000، hand_000 و head_000 دارن — یعنی ۰۰۰ کاملاً یه ایندکس معتبر و معمولیه
    /// برای محتوای واقعیه، نه یه جای رزرو‌شده‌ی خالی. پس وقتی یه کامپوننت کاملاً تازه اضافه
    /// می‌شه (قبلاً هیچی نداشت)، اولین آیتم واقعی مستقیم می‌شینه رو ۰۰۰ — دقیقاً مثل بقیه‌ی
    /// کامپوننت‌های این پد. دیگه هیچ entry جعلی/بدون فایل ساخته نمی‌شه.
    /// </summary>
    public static class YmtComponentEditor
    {
        public static readonly string[] ComponentTypeOrder = new[]
        {
            "HEAD", "BERD", "HAIR", "UPPR", "LOWR", "HAND", "FEET", "TEEF", "ACCS", "TASK", "DECL", "JBIB"
        };

        /// <summary>
        /// این کامپوننت‌ها تو خودِ بازی «اختیاری»ان — یه پد می‌تونه اصلاً چیزی توشون نداشته
        /// باشه (ماسک نداشته باشه، تسک‌آیتم نداشته باشه، بج نداشته باشه، اکسسوری نداشته
        /// باشه، دندون خاصی نداشته باشه). برای این‌ها ایندکس ۰ همیشه باید یعنی «هیچی» بمونه —
        /// نه یه لباس واقعی — چون وقتی پد اسپاون می‌شه و صراحتاً براش چیزی ست نشده، این‌ها رو
        /// ۰ پیش‌فرض می‌گیره. برخلاف کامپوننت‌های «همیشه‌پوشیده» (feet, hair, hand, head,
        /// jbib, lowr, uppr) که پد همیشه یه چیزی توشون داره، پس ۰ اونجا مشکلی نداره.
        /// </summary>
        public static readonly HashSet<string> ReservedZeroComponents =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "berd", "teef", "accs", "task", "decl" };

        public static int GetComponentTypeIndex(string componentName)
        {
            return Array.IndexOf(ComponentTypeOrder, componentName.ToUpperInvariant());
        }

        /// <summary>
        /// تعداد واقعیِ drawable هایی که همین الان تو خودِ سند ymt (نه اسم فایل‌ها!) برای این
        /// کامپوننت ثبت شدن. این تنها منبع قابل‌اعتماده برای اینکه بفهمیم drawblIdx بعدی چیه —
        /// اسم فایل‌های روی دیسک ممکنه (به هر دلیلی) با این عدد یکی نباشه؛ همیشه این تابع رو
        /// به اسکن پوشه ترجیح بده. اگه کامپوننت اصلاً موجود نباشه، ۰ برمی‌گردونه.
        /// </summary>
        public static int GetRealDrawableCount(XmlDocument doc, string componentName)
        {
            if (!IsComponentAvailable(doc, componentName)) return 0;

            int typeIndex = GetComponentTypeIndex(componentName);
            XmlNode root = doc.SelectSingleNode("/CPedVariationInfo");
            XmlNode availCompNode = root.SelectSingleNode("availComp");
            string[] parts = availCompNode.InnerText.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int dataIndex = int.Parse(parts[typeIndex]);

            XmlNode aComponentData3 = root.SelectSingleNode("aComponentData3");
            XmlNodeList compItems = aComponentData3.SelectNodes("Item");
            if (dataIndex >= compItems.Count) return 0;

            XmlNode aDrawblData3 = compItems[dataIndex].SelectSingleNode("aDrawblData3");
            return aDrawblData3.SelectNodes("Item").Count;
        }

        /// <summary>
        /// یه چک ایمن و فقط-خواندنیه (هیچی رو تغییر نمی‌ده): برای هر کامپوننتی که تو
        /// فایل‌های روی دیسک دیده شده، تعداد واقعیِ drawable هایی که خودِ سند ymt براش ثبت
        /// کرده رو با تعداد ایندکس‌های منحصربه‌فردی که از رو اسم فایل‌ها اومده مقایسه می‌کنه.
        /// اگه این دو عدد یکی نباشن، یعنی یه‌جایی اسم فایل با محتوای واقعی ymt ناهم‌خوانه —
        /// دقیقاً همون نوع مشکلی که می‌تونه باعث بشه لباس‌ها تو بازی به‌هم بریزن. این تابع
        /// فقط هشدار می‌ده، خودش هیچی رو درست نمی‌کنه.
        /// </summary>
        public static List<string> CheckFileVsYmtConsistency(XmlDocument doc, IEnumerable<string> componentsFromFileScan, Func<string, int> fileScannedCountPerComponent)
        {
            var warnings = new List<string>();
            foreach (var comp in componentsFromFileScan.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                int realCount = GetRealDrawableCount(doc, comp);
                int fileCount = fileScannedCountPerComponent(comp);
                if (realCount != fileCount)
                {
                    warnings.Add($"⚠ کامپوننت '{comp}': رو دیسک {fileCount} تا فایل با ایندکس یکتا پیدا شد، ولی خودِ ymt {realCount} تا drawable واقعی داره. این ناهم‌خوانی می‌تونه باعث بشه import بعدی اسم فایل اشتباه بسازه — قبل از ادامه بررسیش کن.");
                }
            }
            return warnings;
        }

        public static bool IsComponentAvailable(XmlDocument doc, string componentName)
        {
            int typeIndex = GetComponentTypeIndex(componentName);
            if (typeIndex < 0) return false;

            XmlNode root = doc.SelectSingleNode("/CPedVariationInfo");
            XmlNode availCompNode = root?.SelectSingleNode("availComp");
            if (availCompNode == null) return false;

            string[] parts = availCompNode.InnerText.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (typeIndex >= parts.Length) return false;

            return int.Parse(parts[typeIndex]) != 255;
        }

        public static readonly Dictionary<string, byte> TexSuffixToId = new Dictionary<string, byte>(StringComparer.OrdinalIgnoreCase)
        {
            { "uni", 0 }, { "whi", 1 }, { "bla", 2 }, { "chi", 3 }, { "lat", 4 },
            { "ara", 5 }, { "bal", 6 }, { "jam", 7 }, { "kor", 8 }, { "ita", 9 }, { "pak", 10 },
        };

        public static byte GetTexIdForSuffix(string suffix)
        {
            if (TexSuffixToId.TryGetValue(suffix, out var id)) return id;
            throw new Exception($"پسوند تکسچر ناشناخته: '{suffix}' — نگاشت texId براش تعریف نشده. اگه پسوند جدیده، باید به TexSuffixToId اضافه بشه.");
        }

        static byte GetPropTypeForYddSuffix(string yddSuffix)
        {
            // GetDrawableName تو CodeWalker: PropType 0 -> "u", 1 -> "r", 2/3 -> "m"
            switch ((yddSuffix ?? "u").ToLowerInvariant())
            {
                case "u": return 0;
                case "r": return 1;
                case "m": return 2;
                default: return 0;
            }
        }

        /// <summary>
        /// اگه این ped اصلاً اسلات این تایپ کامپوننت رو نداره (availComp=255)، یه اسلاتِ
        /// کاملاً خالی (بدون هیچ drawable ای) براش باز می‌کنه. اولین آیتم واقعی که بعدش با
        /// AddComponentDrawable اضافه می‌شه، طبیعتاً رو ایندکس ۰ می‌شینه — هیچ entry جعلی
        /// یا فایل اضافه‌ای ساخته نمی‌شه.
        /// </summary>
        public static void EnsureComponentSlot(XmlDocument doc, string componentName)
        {
            if (IsComponentAvailable(doc, componentName)) return;

            int typeIndex = GetComponentTypeIndex(componentName);
            if (typeIndex < 0) throw new Exception("نام کامپوننت ناشناخته: " + componentName);

            XmlNode root = doc.SelectSingleNode("/CPedVariationInfo");
            XmlNode availCompNode = root.SelectSingleNode("availComp");
            string[] parts = availCompNode.InnerText.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            XmlNode aComponentData3 = root.SelectSingleNode("aComponentData3");
            XmlNodeList compItems = aComponentData3.SelectNodes("Item");
            int newDataIndex = compItems.Count;

            parts[typeIndex] = newDataIndex.ToString();
            availCompNode.InnerText = string.Join(" ", parts);

            XmlElement newCompItem = doc.CreateElement("Item");
            XmlElement numAvailTexEl = doc.CreateElement("numAvailTex");
            numAvailTexEl.SetAttribute("value", "0");
            newCompItem.AppendChild(numAvailTexEl);
            XmlElement aDrawblData3El = doc.CreateElement("aDrawblData3");
            aDrawblData3El.SetAttribute("itemType", "CPVDrawblData");
            newCompItem.AppendChild(aDrawblData3El);

            aComponentData3.AppendChild(newCompItem);

            // فقط برای کامپوننت‌های اختیاری (berd/teef/accs/task/decl): ایندکس ۰ باید
            // همیشه یعنی «هیچی» بمونه، نه یه لباس واقعی — چون این‌ها می‌تونن اصلاً پوشیده
            // نشن. برای همین یه entry واقعی (تو خودِ آرایه) با صفر texture و بدون هیچ فایل
            // فیزیکی روش ۰ می‌ذاریم؛ این برخلاف کامپوننت‌های همیشه‌پوشیده (مثل feet/hair)
            // یه حالت کاملاً معتبر و امنه، چون بازی برای این کامپوننت‌ها وقتی چیزی ست نشده
            // اصلاً چیزی رندر نمی‌کنه — نیازی به فایل نداره.
            if (ReservedZeroComponents.Contains(componentName)) // فقط کامپوننت‌های اختیاری — بدنه همیشه یه چیزی می‌پوشه
            {
                AddComponentDrawable(doc, componentName, new List<string>(), "u", isReservedEmptyPlaceholder: true);
            }
        }

        /// <summary>
        /// یه drawable جدید به کامپوننت داده‌شده اضافه می‌کنه و ایندکس drawable جدید رو برمی‌گردونه.
        ///
        /// برخلاف نسخه‌ی قبلی، فیلدهای CComponentInfo (audioID, vfxComps, flags, ...) دیگه با
        /// مقدار ثابتِ حدسی پر نمی‌شن. اگه این کامپوننت از قبل حداقل یه drawable دیگه داشته
        /// باشه، این فیلدها از رو همون sibling کلون می‌شن (چون این‌ها مقادیری‌ان که از قبل رو
        /// این پد امتحان و تأیید شدن). فقط وقتی این کامپوننت کاملاً تازه‌ست (هیچ sibling ای
        /// نداره) از یه fallback خنثی و درست‌ استفاده می‌شه: audioID خالی (هش=۰، یعنی
        /// «بدون صدا»، نه هشِ کلمه‌ی literal "none")، و vfxComps متناظر با خودِ این کامپوننت
        /// (نه همیشه HEAD).
        /// </summary>
        public static int AddComponentDrawable(XmlDocument doc, string componentName, IReadOnlyList<string> texSuffixes, string yddSuffix = "u", bool isReservedEmptyPlaceholder = false)
        {
            int typeIndex = GetComponentTypeIndex(componentName);
            if (typeIndex < 0)
            {
                throw new Exception("نام کامپوننت ناشناخته: " + componentName + " — یکی از این‌ها باید باشه: " + string.Join(", ", ComponentTypeOrder));
            }

            XmlNode root = doc.SelectSingleNode("/CPedVariationInfo");
            if (root == null) throw new Exception("ریشه‌ی CPedVariationInfo پیدا نشد.");

            XmlNode availCompNode = root.SelectSingleNode("availComp");
            string[] availCompParts = availCompNode.InnerText.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int dataIndex = int.Parse(availCompParts[typeIndex]);
            if (dataIndex == 255)
            {
                throw new Exception($"این ped اصلاً کامپوننت {componentName} رو نداره (availComp=255) — اول باید EnsureComponentSlot صدا زده بشه.");
            }

            XmlNode aComponentData3 = root.SelectSingleNode("aComponentData3");
            XmlNodeList compItems = aComponentData3.SelectNodes("Item");
            if (dataIndex >= compItems.Count)
            {
                throw new Exception("dataIndex از تعداد آیتم‌های aComponentData3 بیشتره.");
            }
            XmlNode compItem = compItems[dataIndex];

            XmlNode aDrawblData3 = compItem.SelectSingleNode("aDrawblData3");
            XmlNodeList drawblItems = aDrawblData3.SelectNodes("Item");
            int newDrawblIdx = drawblItems.Count;

            // propMask: نیمه‌ی بالا (PropType) رو از رو پسوند واقعی فایل ydd مبدأ می‌سازیم
            // (u/r/m) — نه صرفاً کپی از drawblItems[0]. نیمه‌ی پایین (که معنیش تو CodeWalker
            // مستند نیست) رو، اگه sibling ای بود، از همون کلون می‌کنیم؛ وگرنه ۰ می‌مونه.
            byte propType = GetPropTypeForYddSuffix(yddSuffix);
            byte lowNibble = 0;
            if (drawblItems.Count > 0)
            {
                var pm = drawblItems[0].SelectSingleNode("propMask");
                if (pm?.Attributes["value"] != null && byte.TryParse(pm.Attributes["value"].Value, out var existingMask))
                {
                    lowNibble = (byte)(existingMask & 0x0F);
                }
            }
            byte propMaskValue = (byte)((propType << 4) | lowNibble);

            XmlElement newDrawblItem = doc.CreateElement("Item");

            XmlElement propMaskEl = doc.CreateElement("propMask");
            propMaskEl.SetAttribute("value", propMaskValue.ToString());
            newDrawblItem.AppendChild(propMaskEl);

            XmlElement numAltEl = doc.CreateElement("numAlternatives");
            numAltEl.SetAttribute("value", "0");
            newDrawblItem.AppendChild(numAltEl);

            XmlElement aTexData = doc.CreateElement("aTexData");
            aTexData.SetAttribute("itemType", "CPVTextureData");
            foreach (var suffix in texSuffixes)
            {
                byte texId = GetTexIdForSuffix(suffix);

                XmlElement texItem = doc.CreateElement("Item");
                XmlElement texIdEl = doc.CreateElement("texId");
                texIdEl.SetAttribute("value", texId.ToString());
                XmlElement dist = doc.CreateElement("distribution");
                // distribution: معنیش تو CodeWalker مستند نیست. اگه یه تکسچر دیگه با همین
                // texId رو همین کامپوننت از قبل بود، مقدارش رو از همونجا کلون می‌کنیم؛
                // وگرنه ۲۵۵ (رفتار پیش‌فرض قبلی) می‌مونه.
                string distValue = FindExistingDistributionForTexId(aDrawblData3, texId) ?? "255";
                dist.SetAttribute("value", distValue);
                texItem.AppendChild(texIdEl);
                texItem.AppendChild(dist);
                aTexData.AppendChild(texItem);
            }
            newDrawblItem.AppendChild(aTexData);

            XmlElement clothData = doc.CreateElement("clothData");
            XmlElement ownsCloth = doc.CreateElement("ownsCloth");
            ownsCloth.SetAttribute("value", "false");
            clothData.AppendChild(ownsCloth);
            newDrawblItem.AppendChild(clothData);

            aDrawblData3.AppendChild(newDrawblItem);

            XmlNode numAvailTexNode = compItem.SelectSingleNode("numAvailTex");
            int currentNumAvailTex = int.Parse(numAvailTexNode.Attributes["value"].Value);
            numAvailTexNode.Attributes["value"].Value = (currentNumAvailTex + texSuffixes.Count).ToString();

            AppendComponentInfo(doc, root, componentName, typeIndex, newDrawblIdx);

            return newDrawblIdx;
        }

        static string FindExistingDistributionForTexId(XmlNode aDrawblData3, byte texId)
        {
            foreach (XmlNode drawbl in aDrawblData3.SelectNodes("Item"))
            {
                foreach (XmlNode tex in drawbl.SelectNodes("aTexData/Item"))
                {
                    var idNode = tex.SelectSingleNode("texId");
                    if (idNode?.Attributes["value"] != null && idNode.Attributes["value"].Value == texId.ToString())
                    {
                        var distNode = tex.SelectSingleNode("distribution");
                        if (distNode?.Attributes["value"] != null) return distNode.Attributes["value"].Value;
                    }
                }
            }
            return null;
        }

        static void AppendComponentInfo(XmlDocument doc, XmlNode root, string componentName, int typeIndex, int newDrawblIdx)
        {
            XmlNode compInfos = root.SelectSingleNode("compInfos");

            // دنبال یه sibling می‌گردیم: یه compInfos Item دیگه که همین pedXml_compIdx رو داره
            // (یعنی یه drawable دیگه‌ی همین کامپوننته) — تا audioID/vfxComps/flags/... رو از
            // روش کلون کنیم، چون این‌ها مقادیری‌ان که از قبل رو این پد درست کار می‌کردن.
            XmlNode template = null;
            foreach (XmlNode item in compInfos.SelectNodes("Item"))
            {
                var compIdxNode = item.SelectSingleNode("pedXml_compIdx");
                if (compIdxNode?.Attributes["value"] != null && compIdxNode.Attributes["value"].Value == typeIndex.ToString())
                {
                    template = item;
                    break;
                }
            }

            XmlElement newCompInfo = doc.CreateElement("Item");

            if (template != null)
            {
                // کلون کامل، بعد فقط drawblIdx رو عوض می‌کنیم
                foreach (XmlNode child in template.ChildNodes)
                {
                    newCompInfo.AppendChild(doc.ImportNode(child, true));
                }
                var drawblIdxNode = newCompInfo.SelectSingleNode("pedXml_drawblIdx");
                if (drawblIdxNode != null)
                    ((XmlElement)drawblIdxNode).SetAttribute("value", newDrawblIdx.ToString());
            }
            else
            {
                // fallback: هیچ sibling ای نبود (کامپوننت کاملاً تازه‌ست) — مقادیر خنثی و
                // واقعی می‌ذاریم، نه یه مقدار hardcode شده‌ی نامرتبط:
                //  - audioID/audioID2: خالی -> هش=۰ (یعنی «بدون صدا»)، نه هشِ کلمه‌ی "none"
                //  - vfxComps: متناظر با خودِ این کامپوننت (PV_COMP_<NAME>)، نه همیشه HEAD
                AddTextEl(doc, newCompInfo, "pedXml_audioID", "");
                AddTextEl(doc, newCompInfo, "pedXml_audioID2", "");
                AddTextEl(doc, newCompInfo, "pedXml_expressionMods", "0 0 0 0 0");
                AddValueEl(doc, newCompInfo, "flags", "0");
                AddTextEl(doc, newCompInfo, "inclusions", "0");
                AddTextEl(doc, newCompInfo, "exclusions", "0");
                AddTextEl(doc, newCompInfo, "pedXml_vfxComps", "PV_COMP_" + componentName.ToUpperInvariant());
                AddValueEl(doc, newCompInfo, "pedXml_flags", "0");
                AddValueEl(doc, newCompInfo, "pedXml_compIdx", typeIndex.ToString());
                AddValueEl(doc, newCompInfo, "pedXml_drawblIdx", newDrawblIdx.ToString());
            }

            compInfos.AppendChild(newCompInfo);
        }

        static void AddTextEl(XmlDocument doc, XmlElement parent, string name, string text)
        {
            var el = doc.CreateElement(name);
            el.InnerText = text;
            parent.AppendChild(el);
        }
        static void AddValueEl(XmlDocument doc, XmlElement parent, string name, string value)
        {
            var el = doc.CreateElement(name);
            el.SetAttribute("value", value);
            parent.AppendChild(el);
        }

        /// <summary>
        /// کل بخش کامپوننت‌های ymt (availComp + aComponentData3 + compInfos) رو از صفر و
        /// فقط بر اساس فایل‌های واقعیِ روی دیسک می‌سازه — یعنی دیگه مهم نیست ymt قبلی چقدر
        /// به‌هم‌ریخته یا ناهم‌خوان بوده، خروجی همیشه دقیقاً منطبق با چیزیه که واقعاً تو
        /// پوشه‌ی stream هست. propInfo و بقیه‌ی بخش‌های ریشه (dlcName، flagها، selectionSets)
        /// دست‌نخورده از templateDoc کپی می‌شن.
        ///
        /// قوانین:
        /// - هر ایندکسی که تو فایل‌ها نبود ولی برای متراکم موندن آرایه لازمه (گپ وسط)، با یه
        ///   entry خالیِ بدون فایل پر می‌شه (کاملاً امنه، چون بازی وقتی چیزی ست نشده چیزی رندر
        ///   نمی‌کنه).
        /// - برای کامپوننت‌های اختیاری (berd/teef/accs/task/decl)، ایندکس ۰ همیشه اجباراً
        ///   خالیه — حتی اگه یه فایل واقعی هم اونجا پیدا بشه (که هشدار می‌ده، نادیده‌ش می‌گیره،
        ///   و پیشنهاد می‌ده اون فایل رو دستی renumber کنی).
        /// - compInfos برای هر drawable واقعی از رو اولین sibling واقعیِ همون کامپوننت (تو
        ///   همین بازسازی) کلون می‌شه؛ برای اولین آیتم هر کامپوننت، fallback خنثیِ همیشگی.
        /// </summary>
        public static XmlDocument RebuildFromFiles(XmlDocument templateDoc, string destFolder, string destPedName, out List<string> renameLog, out List<string> warnings)
        {
            warnings = new List<string>();
            renameLog = new List<string>();
            var allDestFiles = FileNameParser.ScanFolder(destFolder);
            var doc = (XmlDocument)templateDoc.CloneNode(true);
            XmlNode root = doc.SelectSingleNode("/CPedVariationInfo");
            if (root == null) throw new Exception("ریشه‌ی CPedVariationInfo پیدا نشد.");

            var byComponent = allDestFiles
                .GroupBy(d => d.Component, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.OrderBy(d => d.Index).ToList(), StringComparer.OrdinalIgnoreCase);

            // قبل از اینکه چیزی رو دست بزنیم، وضعیت اصلیِ template رو ذخیره می‌کنیم — برای
            // کامپوننت‌هایی که رو دیسک هیچ فایلی ندارن (پس نمی‌تونیم از رو فایل بسازیمشون)
            // این داده‌ی اصلی رو عیناً حفظ می‌کنیم، به‌جای اینکه کلاً حذفشون کنیم. حذف کردنِ
            // یه کامپوننت که تو ymt واقعی بوده (حتی بدون فایل جدا) دقیقاً همون باگیه که باعث
            // می‌شه پد تو بازی غیب بشه.
            var origAvailComp = root.SelectSingleNode("availComp").InnerText.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var origAComponentData3 = root.SelectSingleNode("aComponentData3");
            var origCompInfos = root.SelectSingleNode("compInfos");

            var newAvailComp = Enumerable.Repeat(255, ComponentTypeOrder.Length).ToArray();
            var newAComponentData3 = doc.CreateElement("aComponentData3");
            newAComponentData3.SetAttribute("itemType", "CPVComponentData");
            var newCompInfos = doc.CreateElement("compInfos");
            newCompInfos.SetAttribute("itemType", "CComponentInfo");
            int nextDataIndex = 0;

            // فاز ۱: برای هر کامپوننت، شماره‌ی جدید (همیشه از ۱، بدون گپ) رو حساب کن،
            // و فایل‌هایی که باید عوض بشن رو اول به یه اسم موقت رنیم کن (تا تصادم نشه).
            var finalRenames = new List<(string tempPath, string finalName, string folder)>();
            var itemsWithNewIndex = new Dictionary<string, List<(ClothingDrawable d, int newIndex)>>(StringComparer.OrdinalIgnoreCase);

            foreach (var kv in byComponent)
            {
                string compLower = kv.Key;
                var sorted = kv.Value;
                if (sorted.Count == 0) continue;
                var plan = new List<(ClothingDrawable, int)>();
                bool skipZero = ReservedZeroComponents.Contains(compLower);
                int newIdx = skipZero ? 1 : 0;
                foreach (var d in sorted) { plan.Add((d, newIdx)); newIdx++; }
                itemsWithNewIndex[compLower] = plan;

                foreach (var (d, ni) in plan)
                {
                    if (ni == d.Index) continue; // نیازی به rename نیست
                    if (d.YddPath != null)
                    {
                        string tmp = d.YddPath + ".rebuildtmp";
                        File.Move(d.YddPath, tmp, true);
                        string finalName = FileNameParser.BuildYddFileName(destPedName, compLower, ni, d.YddSuffix);
                        finalRenames.Add((tmp, finalName, Path.GetDirectoryName(d.YddPath)));
                        renameLog.Add($"{Path.GetFileName(d.YddPath)} -> {finalName}");
                    }
                    for (int i = 0; i < d.Textures.Count; i++)
                    {
                        var t = d.Textures[i];
                        string tmp = t.Path + ".rebuildtmp";
                        File.Move(t.Path, tmp, true);
                        const string alphas = "abcdefghijklmnopqrstuvwxyz";
                        string letter = alphas[i % alphas.Length].ToString();
                        string finalName = FileNameParser.BuildDiffYtdFileName(destPedName, compLower, ni, letter, t.TexSuffix);
                        finalRenames.Add((tmp, finalName, Path.GetDirectoryName(t.Path)));
                        renameLog.Add($"{Path.GetFileName(t.Path)} -> {finalName}");
                    }
                }
            }
            // فاز ۲: از اسم موقت به اسم نهایی.
            foreach (var (tempPath, finalName, folder) in finalRenames)
            {
                File.Move(tempPath, Path.Combine(folder, finalName), true);
            }

            // فاز ۳: با شماره‌های جدید (که دیگه گپ ندارن) ymt رو بساز.
            foreach (var compName in ComponentTypeOrder)
            {
                string compLower = compName.ToLowerInvariant();

                if (!itemsWithNewIndex.TryGetValue(compLower, out var plan) || plan.Count == 0)
                {
                    // رو دیسک فایلی براش نبود — اگه تو ymt اصلی وجود داشت، عیناً حفظش کن.
                    int typeIdx = GetComponentTypeIndex(compLower);
                    if (typeIdx >= 0 && typeIdx < origAvailComp.Length && origAvailComp[typeIdx] != "255")
                    {
                        int origDataIdx = int.Parse(origAvailComp[typeIdx]);
                        var origItems = origAComponentData3.SelectNodes("Item");
                        if (origDataIdx < origItems.Count)
                        {
                            newAComponentData3.AppendChild(doc.ImportNode(origItems[origDataIdx], true));
                            foreach (XmlNode ci in origCompInfos.SelectNodes("Item"))
                            {
                                if (ci.SelectSingleNode("pedXml_compIdx")?.Attributes["value"]?.Value == typeIdx.ToString())
                                    newCompInfos.AppendChild(doc.ImportNode(ci, true));
                            }
                            newAvailComp[typeIdx] = nextDataIndex;
                            nextDataIndex++;
                            warnings.Add($"ℹ کامپوننت '{compLower}' رو دیسک فایلی نداشت — داده‌ی اصلیش از ymt قبلی دست‌نخورده حفظ شد.");
                        }
                    }
                    continue;
                }

                int maxIndex = plan.Max(p => p.Item2); // همیشه از ۱ متوالیه، پس maxIndex == plan.Count
                var newCompItem = doc.CreateElement("Item");
                var numAvailTexEl = doc.CreateElement("numAvailTex");
                int totalTex = 0;
                var newDrawblData3 = doc.CreateElement("aDrawblData3");
                newDrawblData3.SetAttribute("itemType", "CPVDrawblData");
                XmlNode firstSiblingCompInfo = null;

                for (int i = 0; i <= maxIndex; i++)
                {
                    var match = plan.FirstOrDefault(p => p.Item2 == i);
                    bool isEmpty = match.Item1 == null;

                    var drawblItem = doc.CreateElement("Item");
                    string yddSuffix = isEmpty ? "u" : match.Item1.YddSuffix;
                    byte propType = GetPropTypeForYddSuffix(yddSuffix);
                    var propMaskEl = doc.CreateElement("propMask");
                    propMaskEl.SetAttribute("value", ((byte)(propType << 4)).ToString());
                    drawblItem.AppendChild(propMaskEl);
                    var numAltEl = doc.CreateElement("numAlternatives");
                    numAltEl.SetAttribute("value", "0");
                    drawblItem.AppendChild(numAltEl);

                    var aTexData = doc.CreateElement("aTexData");
                    aTexData.SetAttribute("itemType", "CPVTextureData");
                    int texCountHere = 0;
                    if (!isEmpty)
                    {
                        foreach (var t in match.Item1.Textures)
                        {
                            if (!TexSuffixToId.TryGetValue(t.TexSuffix, out var texId))
                            {
                                warnings.Add($"⚠ {compLower}_{i:000}: پسوند تکسچر ناشناخته '{t.TexSuffix}' — رد شد.");
                                continue;
                            }
                            var texItem = doc.CreateElement("Item");
                            var texIdEl = doc.CreateElement("texId");
                            texIdEl.SetAttribute("value", texId.ToString());
                            var distEl = doc.CreateElement("distribution");
                            distEl.SetAttribute("value", "255");
                            texItem.AppendChild(texIdEl);
                            texItem.AppendChild(distEl);
                            aTexData.AppendChild(texItem);
                            texCountHere++;
                        }
                    }
                    drawblItem.AppendChild(aTexData);
                    var clothData = doc.CreateElement("clothData");
                    var ownsCloth = doc.CreateElement("ownsCloth");
                    ownsCloth.SetAttribute("value", "false");
                    clothData.AppendChild(ownsCloth);
                    drawblItem.AppendChild(clothData);
                    newDrawblData3.AppendChild(drawblItem);
                    totalTex += texCountHere;

                    var newCompInfoItem = doc.CreateElement("Item");
                    if (firstSiblingCompInfo != null)
                    {
                        foreach (XmlNode child in firstSiblingCompInfo.ChildNodes)
                            newCompInfoItem.AppendChild(doc.ImportNode(child, true));
                        var drawblIdxNode = newCompInfoItem.SelectSingleNode("pedXml_drawblIdx");
                        if (drawblIdxNode != null) ((XmlElement)drawblIdxNode).SetAttribute("value", i.ToString());
                    }
                    else
                    {
                        AddTextEl(doc, newCompInfoItem, "pedXml_audioID", "");
                        AddTextEl(doc, newCompInfoItem, "pedXml_audioID2", "");
                        AddTextEl(doc, newCompInfoItem, "pedXml_expressionMods", "0 0 0 0 0");
                        AddValueEl(doc, newCompInfoItem, "flags", "0");
                        AddTextEl(doc, newCompInfoItem, "inclusions", "0");
                        AddTextEl(doc, newCompInfoItem, "exclusions", "0");
                        AddTextEl(doc, newCompInfoItem, "pedXml_vfxComps", "PV_COMP_" + compName);
                        AddValueEl(doc, newCompInfoItem, "pedXml_flags", "0");
                        AddValueEl(doc, newCompInfoItem, "pedXml_compIdx", GetComponentTypeIndex(compLower).ToString());
                        AddValueEl(doc, newCompInfoItem, "pedXml_drawblIdx", i.ToString());
                        firstSiblingCompInfo = newCompInfoItem;
                    }
                    newCompInfos.AppendChild(newCompInfoItem);
                }

                numAvailTexEl.SetAttribute("value", totalTex.ToString());
                newCompItem.AppendChild(numAvailTexEl);
                newCompItem.AppendChild(newDrawblData3);
                newAComponentData3.AppendChild(newCompItem);
                newAvailComp[GetComponentTypeIndex(compLower)] = nextDataIndex;
                nextDataIndex++;
            }

            var availCompNode = root.SelectSingleNode("availComp");
            availCompNode.InnerText = string.Join(" ", newAvailComp);
            root.ReplaceChild(newAComponentData3, root.SelectSingleNode("aComponentData3"));
            root.ReplaceChild(newCompInfos, root.SelectSingleNode("compInfos"));

            RebuildProps(root, doc, destFolder, warnings);

            return doc;
        }

        /// <summary>
        /// propInfo (کلاه/عینک/گوشواره/ساعت‌های دو دست) رو از رو فایل‌های p_*.ydd/ytd
        /// بازمی‌سازه. برخلاف کامپوننت‌های لباس، پراپ‌ها نیازی به رزرو ایندکس ۰ ندارن —
        /// «چیزی نپوشیدن» تو پراپ‌ها با یه مکانیزم جدا (propIndex=-1 تو اسکریپت) کنترل
        /// می‌شه، نه با خالی‌بودن propId=۰.
        /// فرض اسم فایل: p_&lt;Ped&gt;^p_&lt;slot&gt;_&lt;idx3&gt;_&lt;suffix&gt;.ydd
        /// (slot یکی از: head, eyes, ears, lwrist, rwrist) — طبق قرارداد شناخته‌شده‌ی
        /// YMTEditor. اگه اسم واقعی فرق داره، این تابع باید عوض بشه.
        /// </summary>
        /// <summary>
        /// یه پراپ (کلاه/عینک/گوشواره/ساعت) رو به propInfo اضافه می‌کنه — نسخه‌ی تک‌آیتمیِ
        /// RebuildProps، برای مسیر Import عادی (نه بازسازی کامل). propId جدید رو برمی‌گردونه.
        /// پراپ‌ها ایندکس ۰ رو رزرو نمی‌کنن.
        /// </summary>
        public static int AddPropDrawable(XmlDocument doc, string slot, IReadOnlyList<string> texSuffixes)
        {
            if (!FileNameParser.PropAnchorIds.TryGetValue(slot, out byte anchorId))
                throw new Exception("اسم slot پراپ ناشناخته: " + slot);

            XmlNode root = doc.SelectSingleNode("/CPedVariationInfo");
            var propInfoNode = root.SelectSingleNode("propInfo");
            if (propInfoNode == null)
            {
                propInfoNode = doc.CreateElement("propInfo");
                var numAvailPropsEl0 = doc.CreateElement("numAvailProps");
                numAvailPropsEl0.SetAttribute("value", "0");
                propInfoNode.AppendChild(numAvailPropsEl0);
                root.AppendChild(propInfoNode);
            }

            var metaData = propInfoNode.SelectSingleNode("aPropMetaData");
            if (metaData == null)
            {
                metaData = doc.CreateElement("aPropMetaData");
                ((XmlElement)metaData).SetAttribute("itemType", "CPedPropMetaData");
                propInfoNode.AppendChild(metaData);
            }
            var anchors = propInfoNode.SelectSingleNode("aAnchors");
            if (anchors == null)
            {
                anchors = doc.CreateElement("aAnchors");
                ((XmlElement)anchors).SetAttribute("itemType", "CAnchorProps");
                propInfoNode.AppendChild(anchors);
            }

            // propId جدید = تعداد آیتم‌های موجودِ همین anchor
            var existingForAnchor = metaData.SelectNodes("Item")
                .Cast<XmlNode>()
                .Where(it => it.SelectSingleNode("anchorId")?.Attributes["value"]?.Value == anchorId.ToString())
                .ToList();
            int newPropId = existingForAnchor.Count;

            var item = doc.CreateElement("Item");
            AddTextEl(doc, item, "audioId", "none");
            AddTextEl(doc, item, "expressionMods", "0 0 0 0 0");
            var texData = doc.CreateElement("texData");
            texData.SetAttribute("itemType", "CPedPropTexData");
            foreach (var suffix in texSuffixes.Count > 0 ? texSuffixes : new[] { "uni" })
            {
                byte texId = TexSuffixToId.TryGetValue(suffix, out var tid) ? tid : (byte)0;
                var texItem = doc.CreateElement("Item");
                AddTextEl(doc, texItem, "inclusions", "0");
                AddTextEl(doc, texItem, "exclusions", "0");
                AddValueEl(doc, texItem, "texId", texId.ToString());
                AddValueEl(doc, texItem, "inclusionId", "0");
                AddValueEl(doc, texItem, "exclusionId", "0");
                AddValueEl(doc, texItem, "distribution", "255");
                texData.AppendChild(texItem);
            }
            item.AppendChild(texData);
            item.AppendChild(doc.CreateElement("renderFlags"));
            AddValueEl(doc, item, "propFlags", "0");
            AddValueEl(doc, item, "flags", "0");
            AddValueEl(doc, item, "anchorId", anchorId.ToString());
            AddValueEl(doc, item, "propId", newPropId.ToString());
            AddValueEl(doc, item, "hash_AC887A91", "0");
            metaData.AppendChild(item);

            // شمارنده‌ی anchor مربوطه رو تو aAnchors آپدیت کن — از رو تعداد واقعیِ
            // آیتم‌های همین anchor تو aPropMetaData حساب می‌کنیم (نه parse کردن متنِ
            // round-trip‌شده، که فرمتش بعد از رفت‌وبرگشت باینری می‌تونه فرق کنه).
            int realCountForAnchor = metaData.SelectNodes("Item").Cast<XmlNode>()
                .Count(it => it.SelectSingleNode("anchorId")?.Attributes["value"]?.Value == anchorId.ToString());
            string anchorName = FileNameParser.PropAnchorNames[anchorId];
            XmlNode anchorEntry = anchors.SelectNodes("Item").Cast<XmlNode>()
                .FirstOrDefault(a => a.SelectSingleNode("anchor")?.InnerText == anchorName);
            if (anchorEntry != null)
            {
                anchorEntry.SelectSingleNode("props").InnerText = realCountForAnchor.ToString();
            }
            else
            {
                var anchorItem = doc.CreateElement("Item");
                AddTextEl(doc, anchorItem, "props", realCountForAnchor.ToString());
                AddTextEl(doc, anchorItem, "anchor", anchorName);
                anchors.AppendChild(anchorItem);
            }

            var numAvailPropsNode = propInfoNode.SelectSingleNode("numAvailProps");
            numAvailPropsNode.Attributes["value"].Value = metaData.SelectNodes("Item").Count.ToString();

            return newPropId;
        }

        static void RebuildProps(XmlNode root, XmlDocument doc, string destFolder, List<string> warnings)
        {
            var propInfoNode = root.SelectSingleNode("propInfo");
            if (propInfoNode == null)
            {
                var scannedCheck = FileNameParser.ScanPropsFolder(destFolder);
                if (scannedCheck.Count == 0) return; // نه propInfo داره نه فایل پراپی هست، کاری نکن
                propInfoNode = doc.CreateElement("propInfo");
                var numAvailPropsEl0 = doc.CreateElement("numAvailProps");
                numAvailPropsEl0.SetAttribute("value", "0");
                propInfoNode.AppendChild(numAvailPropsEl0);
                root.AppendChild(propInfoNode);
                warnings.Add("ℹ این ped قبلاً propInfo نداشت — از صفر ساخته شد.");
            }

            var scannedProps = FileNameParser.ScanPropsFolder(destFolder);
            var bySlot = scannedProps
                .Where(p => FileNameParser.PropAnchorIds.ContainsKey(p.Component))
                .GroupBy(p => p.Component, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.OrderBy(p => p.Index).ToList(), StringComparer.OrdinalIgnoreCase);

            foreach (var p in scannedProps)
            {
                if (!FileNameParser.PropAnchorIds.ContainsKey(p.Component))
                    warnings.Add($"⚠ پراپ با اسم slot ناشناخته '{p.Component}' پیدا شد — رد شد (فقط head/eyes/ears/lwrist/rwrist پشتیبانی می‌شه).");
            }

            var newMetaData = doc.CreateElement("aPropMetaData");
            newMetaData.SetAttribute("itemType", "CPedPropMetaData");
            var newAnchors = doc.CreateElement("aAnchors");
            newAnchors.SetAttribute("itemType", "CAnchorProps");
            int totalProps = 0;

            foreach (var slotKv in bySlot)
            {
                byte anchorId = FileNameParser.PropAnchorIds[slotKv.Key];
                string anchorName = FileNameParser.PropAnchorNames[anchorId];
                var items = slotKv.Value;

                foreach (var p in items)
                {
                    var item = doc.CreateElement("Item");
                    AddTextEl(doc, item, "audioId", "none");
                    AddTextEl(doc, item, "expressionMods", "0 0 0 0 0");

                    var texData = doc.CreateElement("texData");
                    texData.SetAttribute("itemType", "CPedPropTexData");
                    foreach (var t in p.Textures)
                    {
                        if (!TexSuffixToId.TryGetValue(t.TexSuffix, out var texId))
                        {
                            warnings.Add($"⚠ پراپ {slotKv.Key}_{p.Index:000}: پسوند تکسچر ناشناخته '{t.TexSuffix}' — رد شد.");
                            continue;
                        }
                        var texItem = doc.CreateElement("Item");
                        AddTextEl(doc, texItem, "inclusions", "0");
                        AddTextEl(doc, texItem, "exclusions", "0");
                        AddValueEl(doc, texItem, "texId", texId.ToString());
                        AddValueEl(doc, texItem, "inclusionId", "0");
                        AddValueEl(doc, texItem, "exclusionId", "0");
                        AddValueEl(doc, texItem, "distribution", "255");
                        texData.AppendChild(texItem);
                    }
                    if (p.Textures.Count == 0)
                    {
                        // حتی اگه تکسچر دیف نداشت، حداقل یه ورودیِ texId=0 لازمه که پراپ اصلاً نمایش داده بشه
                        var texItem = doc.CreateElement("Item");
                        AddTextEl(doc, texItem, "inclusions", "0");
                        AddTextEl(doc, texItem, "exclusions", "0");
                        AddValueEl(doc, texItem, "texId", "0");
                        AddValueEl(doc, texItem, "inclusionId", "0");
                        AddValueEl(doc, texItem, "exclusionId", "0");
                        AddValueEl(doc, texItem, "distribution", "255");
                        texData.AppendChild(texItem);
                    }
                    item.AppendChild(texData);

                    var renderFlags = doc.CreateElement("renderFlags");
                    item.AppendChild(renderFlags);
                    AddValueEl(doc, item, "propFlags", "0");
                    AddValueEl(doc, item, "flags", "0");
                    AddValueEl(doc, item, "anchorId", anchorId.ToString());
                    AddValueEl(doc, item, "propId", p.Index.ToString());
                    AddValueEl(doc, item, "hash_AC887A91", "0");

                    newMetaData.AppendChild(item);
                    totalProps++;
                }

                var anchorItem = doc.CreateElement("Item");
                AddTextEl(doc, anchorItem, "props", items.Count.ToString());
                AddTextEl(doc, anchorItem, "anchor", anchorName);
                newAnchors.AppendChild(anchorItem);
            }

            var numAvailPropsNode = propInfoNode.SelectSingleNode("numAvailProps");
            if (numAvailPropsNode != null) numAvailPropsNode.Attributes["value"].Value = totalProps.ToString();

            var oldMetaData = propInfoNode.SelectSingleNode("aPropMetaData");
            if (oldMetaData != null) propInfoNode.ReplaceChild(newMetaData, oldMetaData);
            else propInfoNode.AppendChild(newMetaData);

            var oldAnchors = propInfoNode.SelectSingleNode("aAnchors");
            if (oldAnchors != null) propInfoNode.ReplaceChild(newAnchors, oldAnchors);
            else propInfoNode.AppendChild(newAnchors);
        }
    }
}