using System.Windows;

namespace PedImporter
{
    public partial class App : Application
    {
    }
}
