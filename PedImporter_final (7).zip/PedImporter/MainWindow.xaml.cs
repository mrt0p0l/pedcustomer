using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows;
using Microsoft.Win32;
using PedImporter.Core;

namespace PedImporter
{
    /// <summary>
    /// یه دور دیگه‌ی ClothingDrawable که برای binding به ListView تیک‌دار لازمه.
    /// </summary>
    public class SelectableDrawable : INotifyPropertyChanged
    {
        public ClothingDrawable Source { get; }
        public SelectableDrawable(ClothingDrawable source) { Source = source; }

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set { _isSelected = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected))); }
        }

        public string StatusText => Source.YddPath == null
            ? "⚠ ydd نداره!"
            : (Source.Textures.Count == 0 ? "⚠ texture نداره!" : "سالم");

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public partial class MainWindow : Window
    {
        private List<ClothingDrawable> _sourceDrawables = new List<ClothingDrawable>();
        private List<ClothingDrawable> _destDrawables = new List<ClothingDrawable>();
        private System.Xml.XmlDocument _destYmtDoc;
        private string _destYmtPath;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Log(string msg)
        {
            LogBox.AppendText(msg + Environment.NewLine);
            LogBox.ScrollToEnd();
        }

        // ---------- انتخاب پوشه‌ها ----------

        private void BrowseSourceButton_Click(object sender, RoutedEventArgs e)
        {
            var path = PickFolder();
            if (path != null)
            {
                SourceFolderBox.Text = path;
                ScanSourceButton_Click(sender, e); // اسکن خودکار، دیگه نیازی به زدن دکمه‌ی جدا نیست
            }
        }

        private void BrowseDestButton_Click(object sender, RoutedEventArgs e)
        {
            var path = PickFolder();
            if (path != null)
            {
                DestFolderBox.Text = path;
                ScanDestButton_Click(sender, e); // اسکن + حدس ymt خودکار، دیگه نیازی به دکمه‌ی جدا نیست
            }
        }

        private void BrowseYmtButton_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "YMT files (*.ymt)|*.ymt" };
            if (!string.IsNullOrEmpty(DestFolderBox.Text) && Directory.Exists(DestFolderBox.Text))
            {
                dlg.InitialDirectory = DestFolderBox.Text;
            }
            if (dlg.ShowDialog() == true)
            {
                _destYmtPath = dlg.FileName;
                DestYmtPathBox.Text = dlg.FileName;
            }
        }

        private static string PickFolder()
        {
            using (var dlg = new System.Windows.Forms.FolderBrowserDialog())
            {
                var result = dlg.ShowDialog();
                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    return dlg.SelectedPath;
                }
            }
            return null;
        }

        // ---------- اسکن ----------

        private void ScanSourceButton_Click(object sender, RoutedEventArgs e)
        {
            if (!Directory.Exists(SourceFolderBox.Text))
            {
                Log("پوشه‌ی مبدأ معتبر نیست.");
                return;
            }
            try
            {
                _sourceDrawables = FileNameParser.ScanFolder(SourceFolderBox.Text);
                _sourceDrawables.AddRange(FileNameParser.ScanPropsFolder(SourceFolderBox.Text));
                SourceListView.ItemsSource = _sourceDrawables.Select(d => new SelectableDrawable(d)).ToList();
                Log($"مبدأ اسکن شد: {_sourceDrawables.Count} drawable پیدا شد.");
            }
            catch (Exception ex)
            {
                Log("خطا تو اسکن مبدأ: " + ex.Message);
            }
        }

        private void RebuildButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(DestFolderBox.Text) || !Directory.Exists(DestFolderBox.Text))
                {
                    Log("اول پوشه‌ی مقصد رو انتخاب کن.");
                    return;
                }
                if (string.IsNullOrEmpty(_destYmtPath) || !File.Exists(_destYmtPath))
                {
                    Log("اول ymt مقصد رو پیدا/انتخاب کن (با دکمه‌ی 'اسکن مجدد' یا 'انتخاب ymt...').");
                    return;
                }

                var confirm = MessageBox.Show(
                    "این کار کل بخش لباس‌های ymt رو از رو فایل‌های واقعیِ همین پوشه از نو می‌سازه، و برای بستن گپ‌ها ممکنه فایل‌های ydd/ytd موجود رو renumber (rename) کنه — همیشه از ۱ متوالی، ۰ همیشه خالی می‌مونه (برای هیچ کامپوننتی چیزی رو ۰ نمی‌شینه). بقیه‌ی ymt دست‌نخورده می‌مونه. قبلش خودش از ymt بکاپ می‌گیره.\n\nمطمئنی؟",
                    "بازسازی کامل ymt", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (confirm != MessageBoxResult.Yes) return;

                var scanForLog = FileNameParser.ScanFolder(DestFolderBox.Text);
                var propScanForLog = FileNameParser.ScanPropsFolder(DestFolderBox.Text);
                Log($"اسکن پوشه: {scanForLog.Count} drawable لباس + {propScanForLog.Count} پراپ پیدا شد:");
                foreach (var g in scanForLog.GroupBy(d => d.Component))
                    Log($"  {g.Key}: {g.Count()} ایندکس ({string.Join(",", g.Select(d => d.Index).OrderBy(i => i))})");
                foreach (var g in propScanForLog.GroupBy(d => d.Component))
                    Log($"  پراپ {g.Key}: {g.Count()} ایندکس ({string.Join(",", g.Select(d => d.Index).OrderBy(i => i))})");

                var backupPath = ImportPlanner.BackupYmt(_destYmtPath);
                Log("بکاپ گرفته شد: " + backupPath);

                var templateDoc = YmtIo.LoadYmtAsXml(_destYmtPath);
                var rebuilt = YmtComponentEditor.RebuildFromFiles(templateDoc, DestFolderBox.Text, DestPedNameBox.Text, out var renameLog, out var warnings);

                if (renameLog.Count > 0)
                {
                    Log($"{renameLog.Count} فایل برای بستن گپ‌ها renumber شد:");
                    foreach (var r in renameLog) Log("  " + r);
                }
                if (warnings.Count > 0)
                {
                    Log("هشدارهای بازسازی:");
                    foreach (var w in warnings) Log("  " + w);
                }
                else
                {
                    Log("بازسازی بدون هیچ هشداری تموم شد — همه‌چیز کاملاً منطبقه.");
                }

                YmtIo.SaveXmlAsYmt(rebuilt, _destYmtPath);
                _destYmtDoc = rebuilt;

                var summary = new List<string> { $"--- REBUILD FROM FILES ({DateTime.Now:yyyy-MM-dd HH:mm:ss}) ---" };
                summary.AddRange(renameLog.Select(r => "  renamed: " + r));
                summary.AddRange(warnings);
                ImportPlanner.AppendManifest(_destYmtPath, summary);

                Log("ymt جدید ذخیره شد. پیشنهاد: با YMTEditor بازش کن و مطمئن شو درست لود می‌شه، قبل از رفتن رو سرور.");

                ScanDestButton_Click(sender, e);
            }
            catch (Exception ex)
            {
                Log("خطا تو بازسازی: " + ex.Message);
            }
        }

        private void ScanDestButton_Click(object sender, RoutedEventArgs e)
        {
            if (!Directory.Exists(DestFolderBox.Text))
            {
                Log("پوشه‌ی مقصد معتبر نیست.");
                return;
            }
            try
            {
                _destDrawables = FileNameParser.ScanFolder(DestFolderBox.Text);
                _destDrawables.AddRange(FileNameParser.ScanPropsFolder(DestFolderBox.Text));
                DestListView.ItemsSource = _destDrawables;
                Log($"مقصد اسکن شد: {_destDrawables.Count} drawable موجود پیدا شد.");

                if (string.IsNullOrEmpty(DestPedNameBox.Text) && _destDrawables.Count > 0)
                {
                    DestPedNameBox.Text = _destDrawables[0].PedName;
                }

                // اگه ymt رو دستی انتخاب نکرده، حدس بزن: یه فایل .ymt که اسمش شبیه ped name باشه
                if (string.IsNullOrEmpty(_destYmtPath))
                {
                    var guess = Directory.GetFiles(DestFolderBox.Text, "*.ymt").FirstOrDefault();
                    if (guess == null)
                    {
                        // شاید ymt یه پوشه بالاتر باشه (کنار stream)
                        var parent = Directory.GetParent(DestFolderBox.Text)?.FullName;
                        if (parent != null) guess = Directory.GetFiles(parent, "*.ymt").FirstOrDefault();
                    }
                    if (guess != null)
                    {
                        _destYmtPath = guess;
                        DestYmtPathBox.Text = guess;
                        Log("فایل ymt مقصد حدس زده شد: " + guess + " (اگه اشتباهه، دستی از 'انتخاب ymt...' عوضش کن)");
                    }
                }
                // چک ناسازگاریِ فقط-خواندنی: اگه اسم فایل‌ها با محتوای واقعیِ ymt یکی نیست،
                // همین‌جا هشدار بده — قبل از این‌که کاربر چیز جدیدی اضافه کنه و بدتر بشه.
                if (!string.IsNullOrEmpty(_destYmtPath) && File.Exists(_destYmtPath))
                {
                    try
                    {
                        var checkDoc = YmtIo.LoadYmtAsXml(_destYmtPath);
                        var fileCounts = _destDrawables
                            .GroupBy(d => d.Component, StringComparer.OrdinalIgnoreCase)
                            .ToDictionary(g => g.Key, g => g.Select(d => d.Index).Distinct().Count(), StringComparer.OrdinalIgnoreCase);
                        var consistencyWarnings = YmtComponentEditor.CheckFileVsYmtConsistency(
                            checkDoc, fileCounts.Keys, comp => fileCounts.TryGetValue(comp, out var c) ? c : 0);
                        foreach (var w in consistencyWarnings) Log(w);
                        if (consistencyWarnings.Count == 0)
                        {
                            Log("چک ناسازگاری: فایل‌های دیسک با محتوای واقعیِ ymt برای همه‌ی کامپوننت‌ها یکی هستن. ✓");
                        }
                    }
                    catch (Exception ex)
                    {
                        Log("نتونستم چک ناسازگاری رو انجام بدم: " + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                Log("خطا تو اسکن مقصد: " + ex.Message);
            }
        }

        // ---------- پیش‌نمایش ----------

        private List<ImportItem> _plan;

        private void SelectAllSourceCheckBox_Click(object sender, RoutedEventArgs e)
        {
            bool check = SelectAllSourceCheckBox.IsChecked == true;
            var items = SourceListView.ItemsSource as List<SelectableDrawable>;
            if (items == null) return;
            foreach (var it in items) it.IsSelected = check;
        }

        private void BuildPreviewButton_Click(object sender, RoutedEventArgs e)
        {
            var selected = (SourceListView.ItemsSource as List<SelectableDrawable>)?
                .Where(s => s.IsSelected).Select(s => s.Source).ToList();

            if (selected == null || selected.Count == 0)
            {
                Log("هیچی از مبدأ تیک نخورده.");
                return;
            }
            if (string.IsNullOrEmpty(_destYmtPath) || !File.Exists(_destYmtPath))
            {
                Log("اول باید فایل ymt مقصد مشخص باشه (اسکن مقصد رو بزن یا دستی انتخاب کن).");
                return;
            }
            if (string.IsNullOrWhiteSpace(DestPedNameBox.Text))
            {
                Log("اسم Ped مقصد رو پر کن.");
                return;
            }

            // یه بار جدا از حالت اجرا لود می‌کنیم، فقط برای چک کردن این‌که هر
            // کامپوننت اصلاً تو ped مقصد موجوده یا نه (بدون تغییر دادن چیزی)
            System.Xml.XmlDocument previewDoc;
            try
            {
                previewDoc = YmtIo.LoadYmtAsXml(_destYmtPath);
            }
            catch (Exception ex)
            {
                Log("نتونستم ymt مقصد رو برای چک کردن بخونم: " + ex.Message);
                return;
            }

            bool fillGaps = FillGapsCheckBox.IsChecked == true;
            _plan = ImportPlanner.PlanImport(selected, _destDrawables, fillGaps);
            var destPedName = DestPedNameBox.Text;
            var previewRows = _plan.Select(p => new PreviewRow(p, destPedName, previewDoc)).ToList();
            PreviewGrid.ItemsSource = previewRows;

            int problemCount = previewRows.Count(r => r.WarningText.StartsWith("⚠"));
            int infoCount = previewRows.Count(r => r.WarningText.StartsWith("ℹ"));
            var msg = $"پیش‌نمایش ساخته شد: {_plan.Count} آیتم.";
            if (problemCount > 0) msg += $" {problemCount} تاشون مشکل دارن (⚠) — قبل از اجرا از انتخاب حذفشون کن.";
            if (infoCount > 0) msg += $" {infoCount} تاشون کامپوننت جدید می‌سازن (ℹ) — طبیعیه، مشکلی نیست.";
            Log(msg);
        }

        public class PreviewRow : INotifyPropertyChanged
        {
            private readonly string _destPedName;
            public ImportItem Item { get; }

            public PreviewRow(ImportItem item, string destPedName, System.Xml.XmlDocument destDocForCheck)
            {
                Item = item;
                _destPedName = destPedName;
                WarningText = "";

                if (item.HasMismatch)
                {
                    WarningText = "⚠ ydd یا texture کم داره";
                }
                else if (!YmtComponentEditor.IsComponentAvailable(destDocForCheck, item.Source.Component))
                {
                    WarningText = $"ℹ کامپوننت '{item.Source.Component}' جدیده — یه اسلات جدید براش ساخته می‌شه";
                    if (item.IsFirstItemOfNewComponent)
                    {
                        WarningText += " (این آیتم اولین موردشه، طبیعتاً رو ۰۰۰ می‌شینه — محتوای واقعیه، خالی/جعلی نیست)";
                    }
                }
            }

            public ClothingDrawable Source => Item.Source;
            public int TextureCount => Item.Source.Textures.Count;

            public string OldKey => Item.Source.Key; // مثلاً oran^feet_007

            public int NewIndex
            {
                get => Item.NewIndex;
                set
                {
                    Item.NewIndex = value;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NewIndex)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NewKey)));
                }
            }

            // مثلاً De3^feet_002 — دقیقاً همون اسمی که فایل‌ها بهش rename می‌شن
            public string NewKey => $"{_destPedName}^{Item.Source.Component}_{Item.NewIndex:D3}";

            public string WarningText { get; }

            public event PropertyChangedEventHandler PropertyChanged;
        }

        // ---------- اجرا ----------

        private void ExecuteButton_Click(object sender, RoutedEventArgs e)
        {
            if (_plan == null || _plan.Count == 0)
            {
                Log("اول باید پیش‌نمایش بسازی.");
                return;
            }
            if (string.IsNullOrEmpty(_destYmtPath) || !File.Exists(_destYmtPath))
            {
                Log("فایل ymt مقصد مشخص/معتبر نیست.");
                return;
            }
            if (string.IsNullOrWhiteSpace(DestPedNameBox.Text))
            {
                Log("اسم Ped مقصد رو پر کن.");
                return;
            }

            try
            {
                // لود تازه، فقط برای اعتبارسنجی قبل از هر تغییری (هیچ فایلی هنوز کپی نشده)
                var checkDoc = YmtIo.LoadYmtAsXml(_destYmtPath);
                var errors = ImportPlanner.ValidatePlan(_plan, checkDoc, _destYmtPath);
                if (errors.Count > 0)
                {
                    Log($"{errors.Count} آیتم مشکل دارن و رد می‌شن، بقیه اجرا می‌شن:");
                    foreach (var err in errors) Log("  - " + err);
                }

                // ۱. بکاپ ymt
                var backupPath = ImportPlanner.BackupYmt(_destYmtPath);
                Log("بکاپ گرفته شد: " + backupPath);

                // ۲. لود ymt به XML (نسخه‌ی تازه برای اعمال تغییرات واقعی)
                _destYmtDoc = YmtIo.LoadYmtAsXml(_destYmtPath);

                // ۳. کپی فایل‌ها + آپدیت XML برای هر آیتم — ایندکس واقعی همیشه از خودِ ymt گرفته می‌شه
                var execLog = ImportPlanner.ExecuteImport(_plan, DestFolderBox.Text, DestPedNameBox.Text, _destYmtDoc, _destYmtPath);
                foreach (var line in execLog) Log(line);

                // ۴. نوشتن ymt جدید (رو همون مسیر اصلی، چون بکاپ قبلاً گرفته شد)
                YmtIo.SaveXmlAsYmt(_destYmtDoc, _destYmtPath);

                // ۵. لاگ import رو کنار ymt ثبت کن
                ImportPlanner.AppendManifest(_destYmtPath, execLog);

                Log($"تموم شد. {_plan.Count} drawable اضافه شد و فایل‌ها کپی شدن. ymt آپدیت و ذخیره شد.");
                Log("پیشنهاد: فایل ymt رو با YMTEditor باز کن و مطمئن شو درست لود می‌شه، قبل از رفتن رو سرور.");

                // اسکن مقصد رو رفرش کن تا لیست جدید رو نشون بده
                ScanDestButton_Click(sender, e);
            }
            catch (Exception ex)
            {
                Log("خطا تو اجرا: " + ex.Message);
                Log("اگه فایلی کپی شده بود، از پوشه‌ی مقصد پاکش کن؛ ymt اصلی چون بکاپ گرفته شده (اگه گرفته شده باشه) قابل برگردوندنه.");
            }
        }
    }
}
